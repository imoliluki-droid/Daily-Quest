package com.dailyquest.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends Activity {
    public static final String CHANNEL_ID = "daily_quest_notifications";
    private static final int NOTIFICATION_REQUEST_CODE = 1001;
    private NotificationManager notificationManager;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        notificationManager=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        createNotificationChannel();
        WebView w=new WebView(this);
        w.setWebViewClient(new WebViewClient());
        WebSettings s=w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        w.addJavascriptInterface(new NotificationBridge(),"AndroidNotifications");
        w.loadUrl("file:///android_asset/index.html");
        setContentView(w);
    }

    private void createNotificationChannel(){
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
            NotificationChannel c=new NotificationChannel(CHANNEL_ID,"Daily Quest",NotificationManager.IMPORTANCE_DEFAULT);
            c.setDescription("W Speed reminders, quests, achievements and phone pings");
            notificationManager.createNotificationChannel(c);
        }
    }
    private boolean notificationsAllowed(){return Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;}
    private void requestNotificationPermission(){if(Build.VERSION.SDK_INT>=33&&!notificationsAllowed())requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_REQUEST_CODE);}

    private void notifyNow(String title,String body){
        if(!notificationsAllowed()){requestNotificationPermission();return;}
        NotificationManager nm=notificationManager;
        android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(this,CHANNEL_ID):new android.app.Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setAutoCancel(true);
        nm.notify((int)(System.currentTimeMillis()%100000),b.build());
    }

    private void scheduleNotification(String title,String body,long delayMs){
        if(!notificationsAllowed()){requestNotificationPermission();return;}
        long trigger=System.currentTimeMillis()+Math.max(1000,delayMs);
        Intent i=new Intent(this,AlarmReceiver.class).putExtra("title",title).putExtra("body",body);
        PendingIntent pi=PendingIntent.getBroadcast(this,(int)(trigger%100000),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        if(am!=null)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,trigger,pi);
    }

    private boolean usageAccessGranted(){
        try{UsageStatsManager u=(UsageStatsManager)getSystemService(USAGE_STATS_SERVICE);long now=System.currentTimeMillis();List<UsageStats> x=u.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,now-60000,now);return x!=null&&!x.isEmpty();}catch(Exception e){return false;}
    }

    private String usageSummary(){
        JSONArray arr=new JSONArray();
        try{
            UsageStatsManager u=(UsageStatsManager)getSystemService(USAGE_STATS_SERVICE);
            Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
            List<UsageStats> list=u.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,c.getTimeInMillis(),System.currentTimeMillis());
            if(list!=null)for(UsageStats x:list){if(x.getTotalTimeInForeground()<=0)continue;JSONObject o=new JSONObject();o.put("package",x.getPackageName());o.put("minutes",x.getTotalTimeInForeground()/60000);arr.put(o);}
        }catch(Exception ignored){}
        return arr.toString();
    }

    public class NotificationBridge {
        @JavascriptInterface public void requestPermission(){runOnUiThread(() -> requestNotificationPermission());}
        @JavascriptInterface public void sendWspeedNotification(String title,String body){runOnUiThread(() -> notifyNow(title,body));}
        @JavascriptInterface public void sendTestNotification(){runOnUiThread(() -> notifyNow("⚔️ Daily Quest","Notification system is working. Try not to ignore it, bum."));}
        @JavascriptInterface public void scheduleNotification(String title,String body,long delayMs){runOnUiThread(() -> scheduleNotification(title,body,delayMs));}
        @JavascriptInterface public void openUsageSettings(){
            try {
                Intent intent=new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } catch(Exception e) {
                try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch(Exception ignored) {}
            }
        }
        @JavascriptInterface public boolean hasUsageAccess(){return usageAccessGranted();}
        @JavascriptInterface public String getUsageSummary(){return usageSummary();}
    }
}
