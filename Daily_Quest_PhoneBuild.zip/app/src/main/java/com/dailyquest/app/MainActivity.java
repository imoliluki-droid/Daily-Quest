package com.dailyquest.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final int NOTIFICATION_REQUEST_CODE = 1001;
    private static final String CHANNEL_ID = "daily_quest_notifications";
    private NotificationManager notificationManager;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        createNotificationChannel();

        WebView w = new WebView(this);
        w.setWebViewClient(new WebViewClient());
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        // The app UI is bundled locally as a trusted file:// asset and calls only HTTPS APIs.
        // This is required for the W Speed web fetch to leave the Android WebView.
        s.setAllowUniversalAccessFromFileURLs(true);
        w.addJavascriptInterface(new NotificationBridge(), "AndroidNotifications");
        w.loadUrl("file:///android_asset/index.html");
        setContentView(w);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Daily Quest", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Daily Quest reminders and test notifications");
            notificationManager.createNotificationChannel(channel);
        }
    }

    private boolean notificationsAllowed() {
        return Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestNativeNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && !notificationsAllowed()) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST_CODE);
        }
    }

    private void showTestNotification() {
        if (!notificationsAllowed()) {
            requestNativeNotificationPermission();
            return;
        }
        android.app.Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new android.app.Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new android.app.Notification.Builder(this);
        }
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
               .setContentTitle("⚔️ Daily Quest")
               .setContentText("Notification system is working!")
               .setAutoCancel(true);
        notificationManager.notify(1001, builder.build());
    }

    public class NotificationBridge {
        @JavascriptInterface
        public void requestPermission() {
            runOnUiThread(() -> requestNativeNotificationPermission());
        }

        @JavascriptInterface
        public void sendTestNotification() {
            runOnUiThread(() -> showTestNotification());
        }
    }
}
