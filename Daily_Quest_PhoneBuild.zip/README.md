# Daily Quest — phone-only APK build

This project is prepared for building an installable Android APK without a PC.

## Easiest phone-only method: GitHub Actions

1. Create a new GitHub repository.
2. Upload the project files while preserving the folder structure.
3. Open **Actions** → **Build Daily Quest APK** → **Run workflow**.
4. Wait for the build to finish.
5. Open the completed workflow run.
6. Under **Artifacts**, download **Daily-Quest-APK**.
7. Extract it and install `app-debug.apk` on Android.

The APK is a debug build, so it is suitable for personal testing/installing. A Play Store release would need a signed release build later.

## Project
- App name: Daily Quest
- Package: com.dailyquest.app
- Min Android: 6.0 (API 23)
- Target/compile SDK: 35
- Uses the existing Daily Quest web app inside Android WebView.
